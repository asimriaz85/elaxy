/*
	author: istockphp.com
*/
jQuery(function($) {
	var val_holder;
	
	$("form input[name='register']").click(function() { // triggred click 
		
		/************** form validation **************/
		val_holder 		= 0;
		var first_name 		= jQuery.trim($("form input[name='first_name']").val()); // first name field
		var last_name 		= jQuery.trim($("form input[name='last_name']").val()); // last name field
		var telephone_number 	= jQuery.trim($("form input[name='telephone_number']").val()); // tele field
		
		var email 		= jQuery.trim($("form input[name='email']").val()); // email field
		var email_regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/; // reg ex email check
		var confirm_email 		= jQuery.trim($("form input[name='confirm_email']").val()); // email field	
		
		var password 		= jQuery.trim($("form input[name='password']").val()); // password field
		
		var confirm_password 		= jQuery.trim($("form input[name='confirm_password']").val()); // password field
		var newsletter				= jQuery.trim($("form input[name='newsletter']").val());
		
		var country					= jQuery.trim($("form input[name='country']").val()); // first name field
		
		if(first_name == "") {
			$("span.first_name_val").html("This field is empty.");
		val_holder = 1;
		}
		
		if(first_name != "") {
			$("span.first_name_val").html("");
		val_holder = 0;
		}
		 
		if(last_name == "") {
			$("span.last_name_val").html("This field is empty.");
		val_holder = 1;
		} 
		
		if(last_name != "") {
			$("span.last_name_val").html("");
		val_holder = 0;
		} 
		
		if(telephone_number == "") {
			$("span.telephone_number_val").html("This field is empty.");
		val_holder = 1;
		} 
		
		if(telephone_number != "") {
			$("span.telephone_number_val").html("");
		val_holder = 0;
		} 
		
		
		
		if(country == "") {
			$("span.country_val").html("This field is empty.");
		val_holder = 1;
		}
		
		if(country != "") {
			$("span.country_val").html("");
		val_holder = 0;
		}
		
		if(password == "") {
			$("span.password_val").html("This field is empty.");
		val_holder = 1;
		} 
		
		if(confirm_password == "") {
			$("span.confirm_password_val").html("This field is empty.");
		val_holder = 1;
		} 
		
		if(password != confirm_password) {
			$("span.confirm_password_val").html("Password not match with confirm password.");
		val_holder = 1;
		}
		
		if(password != "" && confirm_password!="") {
			if(password == confirm_password) {
			$("span.confirm_password_val").html("");
		val_holder = 0;
		}
		}
		
		if(email == "") {
			$("span.email_val").html("This field is empty.");
		val_holder = 1;
		}
		if(email != "") {
			if(!email_regex.test(email)){ // if invalid email
				$("span.email_val").html("Your email is invalid.");
				val_holder = 1;
			} 
		}
		
		if(confirm_email == "") {
			$("span.confirm_email_val").html("This field is empty.");
		val_holder = 1;
		}
		if(confirm_email != "") {
			if(!email_regex.test(confirm_email)){ // if invalid email
				$("span.confirm_email_val").html("Your email is invalid.");
				val_holder = 0;
			} 
		}
		
		if(email != confirm_email){
			
			$("span.confirm_email_val").html("Confirm email not match with email.");
				val_holder = 1;
		}
		
		if(val_holder == 1) {
			return false;
		}  
		val_holder = 0;
		/************** form validation end **************/
		
		/************** start: email exist function and etc. **************/
		$("span.loading").html("<img src='images/ajax_fb_loader.gif'>");
		$("span.validation").html("");
		
		var datastring = 'first_name='+ first_name +'&last_name='+ last_name +'&email='+ email +'&telephone_number='+ telephone_number +'&password=' + password +'&newsletter=' + newsletter; // get data in the form manual
		//var datastring = $('form#mainform').serialize(); // or use serialize

		$.ajax({
					type: "POST", // type
					url: "check_email.php", // request file the 'check_email.php'
					data: datastring, // post the data
					success: function(responseText) { // get the response
						if(responseText == 1) { // if the response is 1
							$("span.email_val").html("<img src='images/invalid.png'> Email are already exist.");
							$("span.loading").html("");
						} else { // else blank response
							if(responseText == "") { 
							
							/*window.location = "register-confirmation.php"*/
							
							window.location.replace("register-confirmation.php?email=" + email);
								/*$("span.loading").html("<img src='images/correct.png'> You are registred.");
								$("span.validation").html("");
								$("form input[type='text']").val('');*/ // optional: empty the field after registration
							}
						}
					} // end success
		}); // ajax end
		/************** end: email exist function and etc. **************/
	}); // click end
}); // jquery end